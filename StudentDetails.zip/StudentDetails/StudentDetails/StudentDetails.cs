﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentDetails
{
    public partial class StudentDetails : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(localDb)\MSSQLLocalDB;Initial Catalog=Sample;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        public int ID = 0;
        public StudentDetails()
        {
            InitializeComponent();
            DisplayData();
        }
        //private void name_Click(object sender, EventArgs e)
        //{

        //}
        //private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{

        //}
        private bool IsValid()
        {
            if (txtFname.Text == string.Empty)
            {
                MessageBox.Show("Name is required", "failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        //private void reset_Click(object sender, EventArgs e)
        //{
        //    NewMethod();
        //}
        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (IsValid())
            {
                cmd = new SqlCommand("insert into tbl_Record(FirstName,LastName,MI,Gender,Address) VALUES(@firstname, @lastname, @mi, @gender, @address)", conn);
                conn.Open();
                cmd.Parameters.AddWithValue("@firstname", txtFname.Text);
                cmd.Parameters.AddWithValue("@lastname", txtLname.Text);
                cmd.Parameters.AddWithValue("@mi", txtMI.Text);
                cmd.Parameters.AddWithValue("@gender", txtGender.Text);
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                //cmd.Parameters.AddWithValue("@birthDay", dtpBirth);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("New Student is Successfully inserted", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }

        private void ClearData()
        {
            txtFname.Clear();
            txtLname.Clear();
            txtMI.Clear();
            txtGender.Clear();
            txtAddress.Clear();
            //dtpBirth.Clear();
            ID = 0;

        }
        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            txtFname.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtLname.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtMI.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtGender.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            //dtpBirth= Convert.ToInt32(dataGridView1.[e.RowIndex].Cells[5].Value);
            txtAddress.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();

        }
        private void DisplayData()
        {
            conn.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from tbl_Record", conn);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ID > 0)
            {
                cmd = new SqlCommand("update tbl_Record set FirstName=@firstname,LastName=@lastname,MI=@mi,Gender=@gender,Address=@address where ID=@id", conn);
                conn.Open();
                cmd.Parameters.AddWithValue("@firstname", txtFname.Text);
                cmd.Parameters.AddWithValue("@lastname", txtLname.Text);
                cmd.Parameters.AddWithValue("@mi", txtMI.Text);
                cmd.Parameters.AddWithValue("@gender", txtGender.Text);
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                //cmd.Parameters.AddWithValue("@birthDay", dtpBirth);
                cmd.Parameters.AddWithValue("@id", this.ID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student Updated", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Student First", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        //Delete Record
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (ID != 0)
            {
                cmd = new SqlCommand("DELETE FROM  tbl_Record WHERE Id=@ID ", conn);
                conn.Open();
                cmd.Parameters.AddWithValue("@ID", this.ID);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Selected Student has been deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Student First", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void StudentDetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sampleDataSet.tbl_Record' table. You can move, or remove it, as needed.
            this.tbl_RecordTableAdapter.Fill(this.sampleDataSet.tbl_Record);
        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            conn.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from tbl_Record  where ID like '" + txtSearch.Text + "%'", conn);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            if (ID > 0)
            {
                cmd = new SqlCommand("select * from tbl_Record  where ID like'" + txtSearch.Text + "'", conn);
                conn.Open();
                DataTable dt = new DataTable();
                adapt.Fill(dt);
                dataGridView1.DataSource = dt;
                cmd.Parameters.AddWithValue("@id", this.ID);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Student Details", "Search?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Record does not exist", "Search?", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            conn.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from tbl_Record", conn);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
            MessageBox.Show("Show All Student Details", "Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void btnExit_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Sure wanna Exit", "App?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            this.Close();
        }
    }
  }
 